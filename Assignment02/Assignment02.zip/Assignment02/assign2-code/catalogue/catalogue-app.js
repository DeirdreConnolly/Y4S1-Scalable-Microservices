var http = require('http'),
    fs = require('fs'),
    url = require('url');
var p = require('path');
var qs = require('querystring');
var mysql = require('mysql');
var root = __dirname;
var headers = [
    "Product Name", "Price", "Picture", "Buy Button"
];

var db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'shop'
});
var cart = [];
var theuser = null;
var theuserid = null;
var theproductid = null;

var server = http.createServer(function (request, response) {
    var path = url.parse(request.url).pathname;
    var url1 = url.parse(request.url);
    if (request.method === 'POST') {
        switch (path) {


            /* TODO - Part 3(b)*/

            // 1. Build a request to be sent to the catalogue microservice – see the register code in the front-end
            // 2. Write code in the catalogue microservice to add the new product into the product table in the shop
            // database - see the register endpoint in the users microservice.
            // 3. Add in validation code


            case "/newProduct":

                var body = '';
                console.log("Add new product ");
                request.on('data', function (data) {
                    body += data;
                    body = JSON.parse(body);
                    query = "INSERT INTO Products (name, price, image)" +
                        "VALUES(?, ?, ?)";
                    db.query(
                        query,
                        [body.name, body.price, body.image],
                        function (err, result) {
                            if (err) {
                                // 2 response is an sql error
                                response.end('{"error": "3"}');
                                throw err;
                            }
                            theuserid = result.insertId;
                            var obj = {
                                id: theproductid
                            }
                            response.end(JSON.stringify(obj));
                            console.log("Testing this works")


                        }
                    );
                });


                break;


        } //switch
    } else {
        switch (path) {


            case "/getProducts"    :
                console.log("getProducts");
                response.writeHead(200, {
                    'Content-Type': 'text/html',
                    'Access-Control-Allow-Origin': '*'
                });
                var query = "SELECT * FROM products ";


                db.query(
                    query,
                    [],
                    function (err, rows) {
                        if (err) throw err;
                        console.log(JSON.stringify(rows, null, 2));
                        response.end(JSON.stringify(rows));
                        console.log("Products sent");
                    }
                );

                break;
            case "/getProduct"    :
                console.log("getProduct");
                var body = "";
                request.on('data', function (data) {
                    body += data;
                });

                request.on('end', function () {
                    var product = JSON.parse(body);
                    response.writeHead(200, {
                        'Content-Type': 'text/html',
                        'Access-Control-Allow-Origin': '*'
                    });
                    console.log(JSON.stringify(product, null, 2));
                    var query = "SELECT * FROM products where productID=" +
                        product.id;


                    db.query(
                        query,
                        [],
                        function (err, rows) {
                            if (err) throw err;
                            console.log(JSON.stringify(rows, null, 2));
                            response.end(JSON.stringify(rows[0]));
                            console.log("Products sent");
                        }
                    );

                });


                break;


        }
    }


});

server.listen(3002);
